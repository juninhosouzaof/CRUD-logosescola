<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Logos - A sua escola de profissões!</title>

    <!--PACOTE DE FAVICON - ÍCONE DO SITE NAS ABAS DOS NAVEGADORES-->
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logosimples-logos-informatica.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="imagens/logosimples-logos-informatica.png" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor"
        crossorigin="anonymous">
</head>

<body>

    <style>
        body {
            margin: auto;
            width: 100%;
            position: relative;
        }
    </style>

    <!--MENU DE NAVEGAÇÃO DO SITE-->
    <?php 
    include('menu.php')
    ?>
    <!--CARD INICIAL COM IMAGEM - ABERTURA DE CONTEÚDO COM SLOGAN DA INSTITUIÇÃO-->
    <div class="card bg-white text-dark w-100 p-4">
        <img src="imagens/sucess-do-seu-futuro.png" class="card-img" alt="...">
    </div>

    <hr>


    <!--RODAPÉ DO SITE-->

    <style>
        .container-rodape {
            width: 100%;
        }
    </style>

    <?php 
    include('rodape.php')
    ?>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
        crossorigin="anonymous"></script>
</body>

</html>