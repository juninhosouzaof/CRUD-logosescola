<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor"
        crossorigin="anonymous">

    <title>Boletim</title>
</head>

<body>


    <!-- Boletim -->
    <?php
    include("conecta.php");
    include("menuAluno.php");
    $matricula=$_SESSION['matricula'];
    $sql = mysqli_query($conecta,"SELECT * FROM aluno WHERE matricula = '$matricula'");
    while($linha = mysqli_fetch_array($sql)){
        $senha=$linha['senha'];
        $disc=$linha['disciplina'];
        $nota=$linha['nota'];
        $nome=$linha['nome'];
        $nota2=$linha['nota2'];
        $media= ($nota + $nota2) / 2; 

echo"<h1 class='text-center 'style='position: relative; margin: auto;'> 

Seu boletim $nome </h1> <table class='table text-center w-50 border border-dark' style='position: relative; margin: auto;'>

  <thead>
    <tr>
      <th scope='col'>Matricula Aluno</th>
      <th scope='col'>Nome</th>
      <th scope='col'>Disciplina</th>
      <th scope='col'>1º Semestre</th>
      <th scope='col'>2º Semestre</th>
      <th scope='col'>Media</th>
    </tr>
  </thead>
  
  <tbody class='table-group-divider'>
    <tr>
      <th scope='row'>$matricula</th>
      <td>$nome</td>
      <td>$disc</td>
      <td>$nota</td>
      <td>$nota2</td>
      <td>$media</td>
    </tr>

  </tbody>
</table>";
    }
?>



        <!--RODAPÉ DO SITE-->

        <?php 
    include('rodape.php')
    ?>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
            crossorigin="anonymous"></script>

</body>

</html>