<html>
<body>
<?php
    include('logado.php');
    include('conecta.php');
?>

        <!--MENU DE NAVEGAÇÃO DO SITE-->
        <nav class="navbar navbar-expand-sm sticky-top fw-bold align-items-center navbar-dark bg-dark">

<!--ÍCONE DA ESCOLA COM LINK DE REDIRECIONAMENTO PARA O INÍCIO-->
<div class="container-fluid align-items-center">

    <a class="navbar-brand" href="#">
        <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">
    </a>            

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!--OPÇÕES DO MENU-->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link" aria-current="page" href="painelAdmAluno.php">Início</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="boletim.php">Meu Boletim</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="eventos.php">Eventos</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="Fale.php">Fale Conosco</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="biblioteca.php">Biblioteca</a>
            </li>

        </ul>
        <!--Botão Login Aluno--> 
        <a href="painelAdmAluno.php">
    <img width="50px" src="imagens/p.png">
    <?php
    $matricula=$_SESSION['matricula'];

    $sql = mysqli_query($conecta,"SELECT * FROM aluno WHERE matricula = '$matricula'");
    while($linha = mysqli_fetch_array($sql)){
        $nome=$linha['nome'];
    } 
    echo"<br><span class='text-white'>$nome</span>";
    ?>
        </a>

        <!--BOTÃO - SAIR/LOGOUT-->
            <div class="p-2">
                    <button class="btn btn-danger " type="submit"><a class="text-white text-decoration-none" href="../index.php">Sair</a></button>
            </div>
    </div>
</div>
</nav>

<hr>

</body>
</html>