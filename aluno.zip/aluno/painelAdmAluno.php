<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Logos - A sua escola de profissões!</title>

    <!--PACOTE DE FAVICON - ÍCONE DO SITE NAS ABAS DOS NAVEGADORES-->
    <link rel="apple-touch-icon" sizes="180x180" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="32x32" href="imagens/logosimples-logos-informatica.png">
    <link rel="icon" type="image/png" sizes="16x16" href="imagens/logosimples-logos-informatica.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="imagens/logosimples-logos-informatica.png" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <!--LINK ASSOCIANDO O CÓDIGO À BIBLIOTECA BOOTSTRAP-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
</head>

<body>

    <!--MENU-->
    <?php
    include('menuAluno.php');
    ?>
    <!--Alerta-->
<?php
    include("conecta.php");
    $matricula=$_SESSION['matricula'];

    $sql = mysqli_query($conecta,"SELECT * FROM aluno WHERE matricula = '$matricula'");
    while($linha = mysqli_fetch_array($sql)){
        $nome=$linha['nome'];
    }
    $PHPtext = "Bem vindo(a) - $nome !!!!!";

    ?>
    <script>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); // Fim alerta!
    </script>


        <!--CARD INICIAL COM IMAGEM - ABERTURA DE CONTEÚDO COM CONVITE PARA MATRÍCULA-->
        <div class="card bg-light text-dark w-50 p-1 container-fluid">
            <!--TÍTULO + IMAGEM BANNER COM LOGOTIPO-->
            <div class="text-center">
                <h3>Meu Painel
                    <span class="badge bg-success">Aluno</span>
                </h3>
            </div>
            <img src="imagens/Banner1.jpg" class="card-img" alt="O SUCESSO do seu futuro é a nossa missão!">


            <!--PAINEL - ALUNO -->
            <div class="card-group container-fluid w-100 text-center p-2">

                <div class="card-body">


                    <div class="list-group">

                        <a href="boletim.php" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h3 class="mb-1">Boletim
                                    <span class="badge bg-success">Online</span>
                                </h3>
                            </div>
                            <small>Veja aqui as suas notas semestrais!</small>
                        </a>


                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Meus dados</h5>
                            </div>
                            <small>Utilize essa seção para consultar seus dados cadastrais.</small>
                        </a>

                        <a href="#" class="list-group-item list-group-item-action" aria-current="true">
                            <div class="d-flex w-100 justify-content-center">
                                <h5 class="mb-1 fw-bold">Minhas disciplinas</h5>
                            </div>
                            <small>Utilize essa seção para consultar as disciplinas você está inscrito.</small>
                        </a>
                    </div>

                </div>



            </div>


        </div>
        <!--RODAPÉ DO SITE-->
        <?php
        include('rodape.php');
        ?>

            <!-- JavaScript Bundle with Popper -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

</html>