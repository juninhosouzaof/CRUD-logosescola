<!--RODAPÉ DO SITE-->
<hr>

<style>
    .container-rodape {
        width: 100%;
    }
</style>

<footer class="bg-dark text-light bottom-0 end-0">

    <table class="text-center text-light fs-4 p-4 w-100 align-items-center">

        <tr>
            <td>

            <p><strong>SGE</strong> - Sistema de Gestão Escolar</p>

            </td>
        </tr>

    </table>

    <table class="table text-center table-dark table-striped w-100">
        <tr>
            <td>

                <img src="imagens/logos-informatica-logo.png" alt="" width="140" height="50">

            </td>
        </tr>
    </table>


    <table class="table text-center table-dark table-striped text-dark w-100">
        <tr>
            <td>
                <p class="text-center mb-3">Desenvolvido por <b>Flávia, Raphael e Rogerio</b> no módulo de MS Project do Curso Técnico em Informática do SENAC Bonsucesso - 2022</p>
            </td>
        </tr>
    </table>


</footer>